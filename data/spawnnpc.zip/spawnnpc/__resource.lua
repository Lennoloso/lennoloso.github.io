-- Set the resource manifest version
resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

-- Define the resource information
description 'Spawn Ped Resource'
version '1.0'

-- Specify the server scripts
server_scripts {
    'server.lua'
}

-- Specify the client scripts
client_scripts {
    'client.lua'
}
