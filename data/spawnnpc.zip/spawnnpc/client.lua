RegisterNetEvent('spawnNpc')
AddEventHandler('spawnNpc', function(npcName, noAI)
    local playerPed = GetPlayerPed(-1)
    local x, y, z = table.unpack(GetEntityCoords(playerPed))

    local modelHash = nil

    if tonumber(npcName) then
        modelHash = tonumber(npcName)
    else
        modelHash = GetHashKey(npcName)
    end

    if IsModelValid(modelHash) then
        RequestModel(modelHash)
        while not HasModelLoaded(modelHash) do
            Citizen.Wait(0)
        end

        local npc = CreatePed(4, modelHash, x, y, z, 0.0, false, false)

        if noAI then
            SetEntityInvincible(npc, false)
            SetEntityCollision(npc, true, true)
            TaskSetBlockingOfNonTemporaryEvents(npc, true)
        else
            TaskWanderStandard(npc, 10.0, 10)
        end
    else
        TriggerEvent('chatMessage', 'SYSTEM', {255, 0, 0}, 'Ungültiges NPC-Modell oder Hash.')
    end
end)
