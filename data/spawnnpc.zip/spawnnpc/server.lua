RegisterCommand('spawnnpc', function(source, args, rawCommand)
    local npcName = table.concat(args, " ")
    local noAI = false

    if string.match(npcName, " noai$") then
        npcName = string.gsub(npcName, " noai$", "")
        noAI = true
    end

    if npcName and npcName ~= "" then
        TriggerClientEvent('spawnNpc', source, npcName, noAI)
    else
        TriggerClientEvent('chatMessage', source, 'SYSTEM', {255, 0, 0}, 'Verwendung: /spawnnpc [NPC-Hash-ID] (noai)')
    end
end, false)
